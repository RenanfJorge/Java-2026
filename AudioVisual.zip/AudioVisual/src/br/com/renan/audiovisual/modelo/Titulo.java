package br.com.renan.audiovisual.modelo;

public class Titulo {
    private String nome;
    private int anoLancamento;
    private boolean incluidoPlano;
    private double somaAvaliacao;
    private int totalAvalidacoes;
    private int duracaoMinutos;

    public int getTotalAvalidacoes(){
        return totalAvalidacoes;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getNome() {
        return nome;
    }

    public int getAnoLancamento() {
        return anoLancamento;
    }

    public void setAnoLancamento(int anoLancamento) {
        this.anoLancamento = anoLancamento;
    }

    public void setIncluidoPlano(boolean incluidoPlano) {
        this.incluidoPlano = incluidoPlano;
    }

    public void setDuracaoMinutos(int duracaoMinutos) {
        this.duracaoMinutos = duracaoMinutos;
    }

    public int getDuracaoMinutos() {
        return duracaoMinutos;
    }

    public void exibirFicha(){
        System.out.println("Nome: " + nome);
        System.out.println("Ano de Lnaçamento: " + anoLancamento);
        System.out.println("Duração em minutos: " + duracaoMinutos);
    }

    public void avalia(double nota){
        somaAvaliacao += nota;
        totalAvalidacoes++;
    }

    public double somaMedia(){
        return somaAvaliacao / totalAvalidacoes;
    }

}
