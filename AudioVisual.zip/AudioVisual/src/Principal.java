import br.com.renan.audiovisual.modelo.Filme;
import br.com.renan.audiovisual.modelo.Serie;

public class Principal {
    public static void main(String[] args) {
        Filme filme = new Filme();


        filme.setNome("Tumulo dos Vagalumes");
        filme.setAnoLancamento(1988);
        filme.setDuracaoMinutos(180);

        filme.exibirFicha();
        filme.avalia(8);
        filme.avalia(5);
        filme.avalia(2);
        System.out.println("Duração do flime: " + filme.getDuracaoMinutos());
        System.out.println(filme.somaMedia());

        Serie serie = new Serie();

        serie.setNome("Dark");
        serie.setAnoLancamento(2016);
        serie.exibirFicha();
        serie.setEpisodiosPorTemporada(8);
        serie.setTemporadas(3);
        serie.setMinutosPorEpisodio(25);
        System.out.println("Duração do serie: " + serie.getDuracaoMinutos() + " minutos");



    }
}